﻿
namespace TeamProject1
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.hWindowControl1 = new HalconDotNet.HWindowControl();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.LogBox = new System.Windows.Forms.TextBox();
            this.Position_btn = new System.Windows.Forms.Button();
            this.accuracyMessBtn = new System.Windows.Forms.Button();
            this.EvaluateBtn = new System.Windows.Forms.Button();
            this.OutputMessBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("楷体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.Location = new System.Drawing.Point(827, 92);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(195, 47);
            this.button1.TabIndex = 0;
            this.button1.Text = "开始";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // hWindowControl1
            // 
            this.hWindowControl1.AutoScroll = true;
            this.hWindowControl1.BackColor = System.Drawing.Color.DarkGray;
            this.hWindowControl1.BorderColor = System.Drawing.Color.DarkGray;
            this.hWindowControl1.ImagePart = new System.Drawing.Rectangle(0, 0, 640, 480);
            this.hWindowControl1.Location = new System.Drawing.Point(11, 10);
            this.hWindowControl1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.hWindowControl1.Name = "hWindowControl1";
            this.hWindowControl1.Size = new System.Drawing.Size(773, 484);
            this.hWindowControl1.TabIndex = 2;
            this.hWindowControl1.UseWaitCursor = true;
            this.hWindowControl1.WindowSize = new System.Drawing.Size(773, 484);
            this.hWindowControl1.HMouseMove += new HalconDotNet.HMouseEventHandler(this.hWindowControl1_HMouseMove);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // LogBox
            // 
            this.LogBox.Location = new System.Drawing.Point(11, 499);
            this.LogBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.LogBox.Multiline = true;
            this.LogBox.Name = "LogBox";
            this.LogBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.LogBox.Size = new System.Drawing.Size(774, 66);
            this.LogBox.TabIndex = 3;
            // 
            // Position_btn
            // 
            this.Position_btn.Font = new System.Drawing.Font("楷体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Position_btn.Location = new System.Drawing.Point(827, 157);
            this.Position_btn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Position_btn.Name = "Position_btn";
            this.Position_btn.Size = new System.Drawing.Size(194, 43);
            this.Position_btn.TabIndex = 4;
            this.Position_btn.Text = "获取参数信息";
            this.Position_btn.UseVisualStyleBackColor = true;
            this.Position_btn.Click += new System.EventHandler(this.Position_btn_Click);
            // 
            // accuracyMessBtn
            // 
            this.accuracyMessBtn.Font = new System.Drawing.Font("楷体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.accuracyMessBtn.Location = new System.Drawing.Point(827, 217);
            this.accuracyMessBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.accuracyMessBtn.Name = "accuracyMessBtn";
            this.accuracyMessBtn.Size = new System.Drawing.Size(194, 44);
            this.accuracyMessBtn.TabIndex = 5;
            this.accuracyMessBtn.Text = "获取参照信息";
            this.accuracyMessBtn.UseVisualStyleBackColor = true;
            this.accuracyMessBtn.Click += new System.EventHandler(this.accuracyMessBtn_Click);
            // 
            // EvaluateBtn
            // 
            this.EvaluateBtn.Font = new System.Drawing.Font("楷体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.EvaluateBtn.Location = new System.Drawing.Point(827, 277);
            this.EvaluateBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.EvaluateBtn.Name = "EvaluateBtn";
            this.EvaluateBtn.Size = new System.Drawing.Size(194, 44);
            this.EvaluateBtn.TabIndex = 6;
            this.EvaluateBtn.Text = "坐标映射";
            this.EvaluateBtn.UseVisualStyleBackColor = true;
            this.EvaluateBtn.Click += new System.EventHandler(this.EvaluateBtn_Click);
            // 
            // OutputMessBtn
            // 
            this.OutputMessBtn.Font = new System.Drawing.Font("楷体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.OutputMessBtn.Location = new System.Drawing.Point(827, 337);
            this.OutputMessBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.OutputMessBtn.Name = "OutputMessBtn";
            this.OutputMessBtn.Size = new System.Drawing.Size(194, 44);
            this.OutputMessBtn.TabIndex = 7;
            this.OutputMessBtn.Text = "文件及图像输出";
            this.OutputMessBtn.UseVisualStyleBackColor = true;
            this.OutputMessBtn.Click += new System.EventHandler(this.OutputMessBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1065, 637);
            this.Controls.Add(this.OutputMessBtn);
            this.Controls.Add(this.EvaluateBtn);
            this.Controls.Add(this.accuracyMessBtn);
            this.Controls.Add(this.Position_btn);
            this.Controls.Add(this.LogBox);
            this.Controls.Add(this.hWindowControl1);
            this.Controls.Add(this.button1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "定位及测量助手";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private HalconDotNet.HWindowControl hWindowControl1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.TextBox LogBox;
        private System.Windows.Forms.Button Position_btn;
        private System.Windows.Forms.Button accuracyMessBtn;
        private System.Windows.Forms.Button EvaluateBtn;
        private System.Windows.Forms.Button OutputMessBtn;
    }
}


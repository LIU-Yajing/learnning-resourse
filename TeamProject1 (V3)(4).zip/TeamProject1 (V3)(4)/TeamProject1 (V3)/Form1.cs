﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HalconDotNet;
using System.Threading;
using System.Collections;
using System.IO;

namespace TeamProject1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        // Local iconic variables 
        ArrayList messagelist = new ArrayList();
        string ImagePath_Object;
        string match_pic;
        string fileName = @"teamproject" + ".csv";

        private void Position_btn_Click(object sender, EventArgs e)
        {
            LogBox.Clear();
            try
            {
                if (messagelist.Count != 0)
                {
                    foreach (string i in messagelist)
                    {
                        ReadLog(i);
                    };
                }
                else
                {
                    MessageBox.Show("未成功定位图片");
                }
            }
            catch(Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }

        public void set_display_font(HTuple hv_WindowHandle, HTuple hv_Size, HTuple hv_Font,
      HTuple hv_Bold, HTuple hv_Slant)
        {
            // Local iconic variables 
            // Local control variables 

            HTuple hv_OS = new HTuple(), hv_Fonts = new HTuple();
            HTuple hv_Style = new HTuple(), hv_Exception = new HTuple();
            HTuple hv_AvailableFonts = new HTuple(), hv_Fdx = new HTuple();
            HTuple hv_Indices = new HTuple();
            HTuple hv_Font_COPY_INP_TMP = new HTuple(hv_Font);
            HTuple hv_Size_COPY_INP_TMP = new HTuple(hv_Size);

            // Initialize local and output iconic variables 
            try
            {
                //This procedure sets the text font of the current window with
                //the specified attributes.
                //
                //Input parameters:
                //WindowHandle: The graphics window for which the font will be set
                //Size: The font size. If Size=-1, the default of 16 is used.
                //Bold: If set to 'true', a bold font is used
                //Slant: If set to 'true', a slanted font is used
                //
                hv_OS.Dispose();
                HOperatorSet.GetSystem("operating_system", out hv_OS);
                if ((int)((new HTuple(hv_Size_COPY_INP_TMP.TupleEqual(new HTuple()))).TupleOr(
                    new HTuple(hv_Size_COPY_INP_TMP.TupleEqual(-1)))) != 0)
                {
                    hv_Size_COPY_INP_TMP.Dispose();
                    hv_Size_COPY_INP_TMP = 16;
                }
                if ((int)(new HTuple(((hv_OS.TupleSubstr(0, 2))).TupleEqual("Win"))) != 0)
                {
                    //Restore previous behaviour
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_Size = ((1.13677 * hv_Size_COPY_INP_TMP)).TupleInt()
                                ;
                            hv_Size_COPY_INP_TMP.Dispose();
                            hv_Size_COPY_INP_TMP = ExpTmpLocalVar_Size;
                        }
                    }
                }
                else
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_Size = hv_Size_COPY_INP_TMP.TupleInt()
                                ;
                            hv_Size_COPY_INP_TMP.Dispose();
                            hv_Size_COPY_INP_TMP = ExpTmpLocalVar_Size;
                        }
                    }
                }
                if ((int)(new HTuple(hv_Font_COPY_INP_TMP.TupleEqual("Courier"))) != 0)
                {
                    hv_Fonts.Dispose();
                    hv_Fonts = new HTuple();
                    hv_Fonts[0] = "Courier";
                    hv_Fonts[1] = "Courier 10 Pitch";
                    hv_Fonts[2] = "Courier New";
                    hv_Fonts[3] = "CourierNew";
                    hv_Fonts[4] = "Liberation Mono";
                }
                else if ((int)(new HTuple(hv_Font_COPY_INP_TMP.TupleEqual("mono"))) != 0)
                {
                    hv_Fonts.Dispose();
                    hv_Fonts = new HTuple();
                    hv_Fonts[0] = "Consolas";
                    hv_Fonts[1] = "Menlo";
                    hv_Fonts[2] = "Courier";
                    hv_Fonts[3] = "Courier 10 Pitch";
                    hv_Fonts[4] = "FreeMono";
                    hv_Fonts[5] = "Liberation Mono";
                }
                else if ((int)(new HTuple(hv_Font_COPY_INP_TMP.TupleEqual("sans"))) != 0)
                {
                    hv_Fonts.Dispose();
                    hv_Fonts = new HTuple();
                    hv_Fonts[0] = "Luxi Sans";
                    hv_Fonts[1] = "DejaVu Sans";
                    hv_Fonts[2] = "FreeSans";
                    hv_Fonts[3] = "Arial";
                    hv_Fonts[4] = "Liberation Sans";
                }
                else if ((int)(new HTuple(hv_Font_COPY_INP_TMP.TupleEqual("serif"))) != 0)
                {
                    hv_Fonts.Dispose();
                    hv_Fonts = new HTuple();
                    hv_Fonts[0] = "Times New Roman";
                    hv_Fonts[1] = "Luxi Serif";
                    hv_Fonts[2] = "DejaVu Serif";
                    hv_Fonts[3] = "FreeSerif";
                    hv_Fonts[4] = "Utopia";
                    hv_Fonts[5] = "Liberation Serif";
                }
                else
                {
                    hv_Fonts.Dispose();
                    hv_Fonts = new HTuple(hv_Font_COPY_INP_TMP);
                }
                hv_Style.Dispose();
                hv_Style = "";
                if ((int)(new HTuple(hv_Bold.TupleEqual("true"))) != 0)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_Style = hv_Style + "Bold";
                            hv_Style.Dispose();
                            hv_Style = ExpTmpLocalVar_Style;
                        }
                    }
                }
                else if ((int)(new HTuple(hv_Bold.TupleNotEqual("false"))) != 0)
                {
                    hv_Exception.Dispose();
                    hv_Exception = "Wrong value of control parameter Bold";
                    throw new HalconException(hv_Exception);
                }
                if ((int)(new HTuple(hv_Slant.TupleEqual("true"))) != 0)
                {
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_Style = hv_Style + "Italic";
                            hv_Style.Dispose();
                            hv_Style = ExpTmpLocalVar_Style;
                        }
                    }
                }
                else if ((int)(new HTuple(hv_Slant.TupleNotEqual("false"))) != 0)
                {
                    hv_Exception.Dispose();
                    hv_Exception = "Wrong value of control parameter Slant";
                    throw new HalconException(hv_Exception);
                }
                if ((int)(new HTuple(hv_Style.TupleEqual(""))) != 0)
                {
                    hv_Style.Dispose();
                    hv_Style = "Normal";
                }
                hv_AvailableFonts.Dispose();
                HOperatorSet.QueryFont(hv_WindowHandle, out hv_AvailableFonts);
                hv_Font_COPY_INP_TMP.Dispose();
                hv_Font_COPY_INP_TMP = "";
                for (hv_Fdx = 0; (int)hv_Fdx <= (int)((new HTuple(hv_Fonts.TupleLength())) - 1); hv_Fdx = (int)hv_Fdx + 1)
                {
                    hv_Indices.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_Indices = hv_AvailableFonts.TupleFind(
                            hv_Fonts.TupleSelect(hv_Fdx));
                    }
                    if ((int)(new HTuple((new HTuple(hv_Indices.TupleLength())).TupleGreater(
                        0))) != 0)
                    {
                        if ((int)(new HTuple(((hv_Indices.TupleSelect(0))).TupleGreaterEqual(0))) != 0)
                        {
                            hv_Font_COPY_INP_TMP.Dispose();
                            using (HDevDisposeHelper dh = new HDevDisposeHelper())
                            {
                                hv_Font_COPY_INP_TMP = hv_Fonts.TupleSelect(
                                    hv_Fdx);
                            }
                            break;
                        }
                    }
                }
                if ((int)(new HTuple(hv_Font_COPY_INP_TMP.TupleEqual(""))) != 0)
                {
                    throw new HalconException("Wrong value of control parameter Font");
                }
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    {
                        HTuple
                          ExpTmpLocalVar_Font = (((hv_Font_COPY_INP_TMP + "-") + hv_Style) + "-") + hv_Size_COPY_INP_TMP;
                        hv_Font_COPY_INP_TMP.Dispose();
                        hv_Font_COPY_INP_TMP = ExpTmpLocalVar_Font;
                    }
                }
                HOperatorSet.SetFont(hv_WindowHandle, hv_Font_COPY_INP_TMP);

                hv_Font_COPY_INP_TMP.Dispose();
                hv_Size_COPY_INP_TMP.Dispose();
                hv_OS.Dispose();
                hv_Fonts.Dispose();
                hv_Style.Dispose();
                hv_Exception.Dispose();
                hv_AvailableFonts.Dispose();
                hv_Fdx.Dispose();
                hv_Indices.Dispose();

                return;
            }
            catch (HalconException HDevExpDefaultException)
            {

                hv_Font_COPY_INP_TMP.Dispose();
                hv_Size_COPY_INP_TMP.Dispose();
                hv_OS.Dispose();
                hv_Fonts.Dispose();
                hv_Style.Dispose();
                hv_Exception.Dispose();
                hv_AvailableFonts.Dispose();
                hv_Fdx.Dispose();
                hv_Indices.Dispose();

                throw HDevExpDefaultException;
            }
        }

        private void get_standarlization(string match_pic_address)
        {
            // Local iconic variables 

            HObject ho_Image;

            // Local control variables 

            HTuple hv_O = new HTuple(), hv_RM1 = new HTuple();
            HTuple hv_TM = new HTuple(), hv_Ratio = new HTuple();
            // Initialize local and output iconic variables 
            HOperatorSet.GenEmptyObj(out ho_Image);
            ho_Image.Dispose();
            HOperatorSet.ReadImage(out ho_Image, match_pic_address);
            if (HDevWindowStack.IsOpen())
            {
                HOperatorSet.CloseWindow(HDevWindowStack.Pop());
            }
            hv_O.Dispose(); hv_RM1.Dispose(); hv_TM.Dispose(); hv_Ratio.Dispose();
            cal_checkerboard(ho_Image, out hv_O, out hv_RM1, out hv_TM, out hv_Ratio);
            LogBox.Clear();
            ReadLog("获取的原点坐标为："+"("+hv_O[0]+","+hv_O[1]+")");
            ReadLog("获取的像素单量为：" + hv_Ratio);
            ho_Image.Dispose();

            hv_O.Dispose();
            hv_RM1.Dispose();
            hv_TM.Dispose();
            hv_Ratio.Dispose();
        }

        public void cal_checkerboard(HObject ho_Image, out HTuple hv_O, out HTuple hv_RM1,
      out HTuple hv_TM, out HTuple hv_Ratio)
        {



            // Local iconic variables 

            HObject ho_R, ho_G, ho_B, ho_H, ho_S, ho_V;
            HObject ho_Regions, ho_ConnectedRegions, ho_SelectedRegions;
            HObject ho_Skeleton, ho_Contours, ho_ContoursSplit, ho_SelectedContours;
            HObject ho_UnionContours, ho_ImageEmphasize, ho_ImageMedian;
            HObject ho_Regions1, ho_RegionErosion, ho_ConnectedRegions1;
            HObject ho_SelectedRegions1, ho_ObjectSelected, ho_ImageAffineTrans;
            HObject ho_RegionDilation;

            // Local control variables 

            HTuple hv_Width = new HTuple(), hv_Height = new HTuple();
            HTuple hv_WindowHandle = new HTuple(), hv_Number1 = new HTuple();
            HTuple hv_RowBegin = new HTuple(), hv_ColBegin = new HTuple();
            HTuple hv_RowEnd = new HTuple(), hv_ColEnd = new HTuple();
            HTuple hv_Nr = new HTuple(), hv_Nc = new HTuple(), hv_Dist = new HTuple();
            HTuple hv_Row = new HTuple(), hv_Column = new HTuple();
            HTuple hv_IsOverlapping = new HTuple(), hv_Number = new HTuple();
            HTuple hv_Row1 = new HTuple(), hv_Column1 = new HTuple();
            HTuple hv_Phi = new HTuple(), hv_Length1 = new HTuple();
            HTuple hv_Length2 = new HTuple(), hv_HomMat2D = new HTuple();
            HTuple hv_M = new HTuple(), hv_RM = new HTuple(), hv_Area = new HTuple();
            HTuple hv_Row2 = new HTuple(), hv_Column2 = new HTuple();
            HTuple hv_L = new HTuple(), hv_Mean = new HTuple();
            // Initialize local and output iconic variables 
            HOperatorSet.GenEmptyObj(out ho_R);
            HOperatorSet.GenEmptyObj(out ho_G);
            HOperatorSet.GenEmptyObj(out ho_B);
            HOperatorSet.GenEmptyObj(out ho_H);
            HOperatorSet.GenEmptyObj(out ho_S);
            HOperatorSet.GenEmptyObj(out ho_V);
            HOperatorSet.GenEmptyObj(out ho_Regions);
            HOperatorSet.GenEmptyObj(out ho_ConnectedRegions);
            HOperatorSet.GenEmptyObj(out ho_SelectedRegions);
            HOperatorSet.GenEmptyObj(out ho_Skeleton);
            HOperatorSet.GenEmptyObj(out ho_Contours);
            HOperatorSet.GenEmptyObj(out ho_ContoursSplit);
            HOperatorSet.GenEmptyObj(out ho_SelectedContours);
            HOperatorSet.GenEmptyObj(out ho_UnionContours);
            HOperatorSet.GenEmptyObj(out ho_ImageEmphasize);
            HOperatorSet.GenEmptyObj(out ho_ImageMedian);
            HOperatorSet.GenEmptyObj(out ho_Regions1);
            HOperatorSet.GenEmptyObj(out ho_RegionErosion);
            HOperatorSet.GenEmptyObj(out ho_ConnectedRegions1);
            HOperatorSet.GenEmptyObj(out ho_SelectedRegions1);
            HOperatorSet.GenEmptyObj(out ho_ObjectSelected);
            HOperatorSet.GenEmptyObj(out ho_ImageAffineTrans);
            HOperatorSet.GenEmptyObj(out ho_RegionDilation);
            hv_O = new HTuple();
            hv_RM1 = new HTuple();
            hv_TM = new HTuple();
            hv_Ratio = new HTuple();

            hv_Width.Dispose(); hv_Height.Dispose();
            HOperatorSet.GetImageSize(ho_Image, out hv_Width, out hv_Height);
            if (HDevWindowStack.IsOpen())
            {
                HOperatorSet.CloseWindow(HDevWindowStack.Pop());
            }
            HOperatorSet.SetWindowAttr("background_color", "black");
            HOperatorSet.OpenWindow(0, 0, hWindowControl1.Width, hWindowControl1.Height, hWindowControl1.HalconWindow, "", "", out hv_WindowHandle);
            //HOperatorSet.OpenWindow(0, 0, hv_Width / 3, hv_Height / 3, 0, "visible", "", out hv_WindowHandle);
            HDevWindowStack.Push(hv_WindowHandle);
            if (HDevWindowStack.IsOpen())
            {
                HOperatorSet.DispObj(ho_Image, HDevWindowStack.GetActive());
            }
            //提取坐标系
            ho_R.Dispose(); ho_G.Dispose(); ho_B.Dispose();
            HOperatorSet.Decompose3(ho_Image, out ho_R, out ho_G, out ho_B);
            ho_H.Dispose(); ho_S.Dispose(); ho_V.Dispose();
            HOperatorSet.TransFromRgb(ho_R, ho_G, ho_B, out ho_H, out ho_S, out ho_V, "hsv");
            ho_Regions.Dispose();
            HOperatorSet.Threshold(ho_H, out ho_Regions, 240, 255);
            ho_ConnectedRegions.Dispose();
            HOperatorSet.Connection(ho_Regions, out ho_ConnectedRegions);
            ho_SelectedRegions.Dispose();
            HOperatorSet.SelectShape(ho_ConnectedRegions, out ho_SelectedRegions, "outer_radius",
                "and", 50, 99999);
            //select_shape (ConnectedRegions, SelectedRegions, 'area', 'and', 8000, 9999)
            ////即坐标面积很小就不适用

            //生成线、原点坐标
            ho_Skeleton.Dispose();
            HOperatorSet.Skeleton(ho_SelectedRegions, out ho_Skeleton);
            ho_Contours.Dispose();
            HOperatorSet.GenContourRegionXld(ho_Skeleton, out ho_Contours, "border");
            ho_ContoursSplit.Dispose();
            HOperatorSet.SegmentContoursXld(ho_Contours, out ho_ContoursSplit, "lines_circles",
                5, 4, 2);
            ho_SelectedContours.Dispose();
            HOperatorSet.SelectContoursXld(ho_ContoursSplit, out ho_SelectedContours, "contour_length",
                100, 200, -0.5, 0.5);
            hv_Number1.Dispose();
            HOperatorSet.CountObj(ho_SelectedContours, out hv_Number1);
            if ((int)(new HTuple(hv_Number1.TupleLess(4))) != 0)
            {
                disp_message(hv_WindowHandle, "筛选线段有误，请重新调整参数！", "window", 12,
                    12, "black", "true");
            }
            ho_UnionContours.Dispose();
            HOperatorSet.UnionCollinearContoursXld(ho_SelectedContours, out ho_UnionContours,
                200, 1, 2, 0.1, "attr_keep");
            hv_RowBegin.Dispose(); hv_ColBegin.Dispose(); hv_RowEnd.Dispose(); hv_ColEnd.Dispose(); hv_Nr.Dispose(); hv_Nc.Dispose(); hv_Dist.Dispose();
            HOperatorSet.FitLineContourXld(ho_UnionContours, "tukey", -1, 0, 5, 2, out hv_RowBegin,
                out hv_ColBegin, out hv_RowEnd, out hv_ColEnd, out hv_Nr, out hv_Nc, out hv_Dist);
            using (HDevDisposeHelper dh = new HDevDisposeHelper())
            {
                hv_Row.Dispose(); hv_Column.Dispose(); hv_IsOverlapping.Dispose();
                HOperatorSet.IntersectionLines(hv_RowBegin.TupleSelect(0), hv_ColBegin.TupleSelect(
                    0), hv_RowEnd.TupleSelect(0), hv_ColEnd.TupleSelect(0), hv_RowBegin.TupleSelect(
                    1), hv_ColBegin.TupleSelect(1), hv_RowEnd.TupleSelect(1), hv_ColEnd.TupleSelect(
                    1), out hv_Row, out hv_Column, out hv_IsOverlapping);
            }
            hv_O.Dispose();
            using (HDevDisposeHelper dh = new HDevDisposeHelper())
            {
                hv_O = new HTuple();
                hv_O = hv_O.TupleConcat(hv_Row, hv_Column);
            }



            //旋转矫正、计算变换矩阵
            ho_ImageEmphasize.Dispose();
            HOperatorSet.Emphasize(ho_G, out ho_ImageEmphasize, hv_Width, hv_Height, 1);
            ho_ImageMedian.Dispose();
            HOperatorSet.MedianImage(ho_ImageEmphasize, out ho_ImageMedian, "square", 5,
                "mirrored");
            ho_Regions1.Dispose();
            HOperatorSet.Threshold(ho_ImageMedian, out ho_Regions1, 140, 255);
            ho_RegionErosion.Dispose();
            HOperatorSet.ErosionRectangle1(ho_Regions1, out ho_RegionErosion, 11, 11);
            ho_ConnectedRegions1.Dispose();
            HOperatorSet.Connection(ho_RegionErosion, out ho_ConnectedRegions1);
            ho_SelectedRegions1.Dispose();
            HOperatorSet.SelectShape(ho_ConnectedRegions1, out ho_SelectedRegions1, (new HTuple("area")).TupleConcat(
                "rectangularity"), "and", (new HTuple(6500)).TupleConcat(0.9), (new HTuple(7000)).TupleConcat(
                1));
            hv_Number.Dispose();
            HOperatorSet.CountObj(ho_SelectedRegions1, out hv_Number);
            if ((int)(new HTuple(hv_Number.TupleEqual(0))) != 0)
            {
                disp_message(hv_WindowHandle, new HTuple("标定板误差,请检查标定板类型！"),
                    "window", 12, 12, "black", "true");
            }
            using (HDevDisposeHelper dh = new HDevDisposeHelper())
            {
                ho_ObjectSelected.Dispose();
                HOperatorSet.SelectObj(ho_SelectedRegions1, out ho_ObjectSelected, hv_Number / 2);
            }
            hv_Row1.Dispose(); hv_Column1.Dispose(); hv_Phi.Dispose(); hv_Length1.Dispose(); hv_Length2.Dispose();
            HOperatorSet.SmallestRectangle2(ho_ObjectSelected, out hv_Row1, out hv_Column1,
                out hv_Phi, out hv_Length1, out hv_Length2);
            using (HDevDisposeHelper dh = new HDevDisposeHelper())
            {
                hv_HomMat2D.Dispose();
                HOperatorSet.VectorAngleToRigid(hv_Row, hv_Column, hv_Phi, hv_Row, hv_Column,
                    (new HTuple(360)).TupleRad(), out hv_HomMat2D);
            }
            ho_ImageAffineTrans.Dispose();
            HOperatorSet.AffineTransImage(ho_Image, out ho_ImageAffineTrans, hv_HomMat2D,
                "constant", "false");
            if (HDevWindowStack.IsOpen())
            {
                HOperatorSet.DispObj(ho_Image, HDevWindowStack.GetActive());
            }


            //求坐标转换矩阵
            hv_M.Dispose();
            using (HDevDisposeHelper dh = new HDevDisposeHelper())
            {
                hv_M = new HTuple();
                hv_M = hv_M.TupleConcat(hv_HomMat2D.TupleSelect(
                    0));
                hv_M = hv_M.TupleConcat(-(hv_HomMat2D.TupleSelect(1)));
                hv_M = hv_M.TupleConcat(hv_HomMat2D.TupleSelect(
                    3));
                hv_M = hv_M.TupleConcat(-(hv_HomMat2D.TupleSelect(4)));
            }
            hv_RM.Dispose();
            HOperatorSet.CreateMatrix(2, 2, hv_M, out hv_RM);
            hv_RM1.Dispose();
            HOperatorSet.InvertMatrix(hv_RM, "general", 0, out hv_RM1);
            hv_TM.Dispose();
            HOperatorSet.CreateMatrix(2, 1, hv_O, out hv_TM);


            //计算格子像素
            ho_RegionDilation.Dispose();
            HOperatorSet.DilationRectangle1(ho_SelectedRegions1, out ho_RegionDilation, 11,
                11);
            hv_Area.Dispose(); hv_Row2.Dispose(); hv_Column2.Dispose();
            HOperatorSet.AreaCenter(ho_RegionDilation, out hv_Area, out hv_Row2, out hv_Column2);
            hv_L.Dispose();
            HOperatorSet.TupleSqrt(hv_Area, out hv_L);
            hv_Mean.Dispose();
            HOperatorSet.TupleMean(hv_L, out hv_Mean);

            //像素转实际物理尺寸
            hv_Ratio.Dispose();
            using (HDevDisposeHelper dh = new HDevDisposeHelper())
            {
                hv_Ratio = 1 / hv_Mean;
            }

            using (HDevDisposeHelper dh = new HDevDisposeHelper())
            {
                disp_message(hv_WindowHandle, "原点坐标：" + hv_O, "window", 0, 0, "black", "true");
            }
            using (HDevDisposeHelper dh = new HDevDisposeHelper())
            {
                disp_message(hv_WindowHandle, "像素单量：" + hv_Ratio, "window", 30, 0, "black",
                    "true");
            }

            ho_R.Dispose();
            ho_G.Dispose();
            ho_B.Dispose();
            ho_H.Dispose();
            ho_S.Dispose();
            ho_V.Dispose();
            ho_Regions.Dispose();
            ho_ConnectedRegions.Dispose();
            ho_SelectedRegions.Dispose();
            ho_Skeleton.Dispose();
            ho_Contours.Dispose();
            ho_ContoursSplit.Dispose();
            ho_SelectedContours.Dispose();
            ho_UnionContours.Dispose();
            ho_ImageEmphasize.Dispose();
            ho_ImageMedian.Dispose();
            ho_Regions1.Dispose();
            ho_RegionErosion.Dispose();
            ho_ConnectedRegions1.Dispose();
            ho_SelectedRegions1.Dispose();
            ho_ObjectSelected.Dispose();
            ho_ImageAffineTrans.Dispose();
            ho_RegionDilation.Dispose();

            hv_Width.Dispose();
            hv_Height.Dispose();
            hv_WindowHandle.Dispose();
            hv_Number1.Dispose();
            hv_RowBegin.Dispose();
            hv_ColBegin.Dispose();
            hv_RowEnd.Dispose();
            hv_ColEnd.Dispose();
            hv_Nr.Dispose();
            hv_Nc.Dispose();
            hv_Dist.Dispose();
            hv_Row.Dispose();
            hv_Column.Dispose();
            hv_IsOverlapping.Dispose();
            hv_Number.Dispose();
            hv_Row1.Dispose();
            hv_Column1.Dispose();
            hv_Phi.Dispose();
            hv_Length1.Dispose();
            hv_Length2.Dispose();
            hv_HomMat2D.Dispose();
            hv_M.Dispose();
            hv_RM.Dispose();
            hv_Area.Dispose();
            hv_Row2.Dispose();
            hv_Column2.Dispose();
            hv_L.Dispose();
            hv_Mean.Dispose();

            return;
            ho_R.Dispose();
            ho_G.Dispose();
            ho_B.Dispose();
            ho_H.Dispose();
            ho_S.Dispose();
            ho_V.Dispose();
            ho_Regions.Dispose();
            ho_ConnectedRegions.Dispose();
            ho_SelectedRegions.Dispose();
            ho_Skeleton.Dispose();
            ho_Contours.Dispose();
            ho_ContoursSplit.Dispose();
            ho_SelectedContours.Dispose();
            ho_UnionContours.Dispose();
            ho_ImageEmphasize.Dispose();
            ho_ImageMedian.Dispose();
            ho_Regions1.Dispose();
            ho_RegionErosion.Dispose();
            ho_ConnectedRegions1.Dispose();
            ho_SelectedRegions1.Dispose();
            ho_ObjectSelected.Dispose();
            ho_ImageAffineTrans.Dispose();
            ho_RegionDilation.Dispose();

            hv_Width.Dispose();
            hv_Height.Dispose();
            hv_WindowHandle.Dispose();
            hv_Number1.Dispose();
            hv_RowBegin.Dispose();
            hv_ColBegin.Dispose();
            hv_RowEnd.Dispose();
            hv_ColEnd.Dispose();
            hv_Nr.Dispose();
            hv_Nc.Dispose();
            hv_Dist.Dispose();
            hv_Row.Dispose();
            hv_Column.Dispose();
            hv_IsOverlapping.Dispose();
            hv_Number.Dispose();
            hv_Row1.Dispose();
            hv_Column1.Dispose();
            hv_Phi.Dispose();
            hv_Length1.Dispose();
            hv_Length2.Dispose();
            hv_HomMat2D.Dispose();
            hv_M.Dispose();
            hv_RM.Dispose();
            hv_Area.Dispose();
            hv_Row2.Dispose();
            hv_Column2.Dispose();
            hv_L.Dispose();
            hv_Mean.Dispose();

            return;
        }

        // Chapter: Graphics / Text
        // Short Description: This procedure writes a text message. 
        public void disp_message(HTuple hv_WindowHandle, HTuple hv_String, HTuple hv_CoordSystem,
            HTuple hv_Row, HTuple hv_Column, HTuple hv_Color, HTuple hv_Box)
        {



            // Local iconic variables 

            // Local control variables 

            HTuple hv_GenParamName = new HTuple(), hv_GenParamValue = new HTuple();
            HTuple hv_Color_COPY_INP_TMP = new HTuple(hv_Color);
            HTuple hv_Column_COPY_INP_TMP = new HTuple(hv_Column);
            HTuple hv_CoordSystem_COPY_INP_TMP = new HTuple(hv_CoordSystem);
            HTuple hv_Row_COPY_INP_TMP = new HTuple(hv_Row);

            // Initialize local and output iconic variables 
            //This procedure displays text in a graphics window.
            //
            //Input parameters:
            //WindowHandle: The WindowHandle of the graphics window, where
            //   the message should be displayed
            //String: A tuple of strings containing the text message to be displayed
            //CoordSystem: If set to 'window', the text position is given
            //   with respect to the window coordinate system.
            //   If set to 'image', image coordinates are used.
            //   (This may be useful in zoomed images.)
            //Row: The row coordinate of the desired text position
            //   A tuple of values is allowed to display text at different
            //   positions.
            //Column: The column coordinate of the desired text position
            //   A tuple of values is allowed to display text at different
            //   positions.
            //Color: defines the color of the text as string.
            //   If set to [], '' or 'auto' the currently set color is used.
            //   If a tuple of strings is passed, the colors are used cyclically...
            //   - if |Row| == |Column| == 1: for each new textline
            //   = else for each text position.
            //Box: If Box[0] is set to 'true', the text is written within an orange box.
            //     If set to' false', no box is displayed.
            //     If set to a color string (e.g. 'white', '#FF00CC', etc.),
            //       the text is written in a box of that color.
            //     An optional second value for Box (Box[1]) controls if a shadow is displayed:
            //       'true' -> display a shadow in a default color
            //       'false' -> display no shadow
            //       otherwise -> use given string as color string for the shadow color
            //
            //It is possible to display multiple text strings in a single call.
            //In this case, some restrictions apply:
            //- Multiple text positions can be defined by specifying a tuple
            //  with multiple Row and/or Column coordinates, i.e.:
            //  - |Row| == n, |Column| == n
            //  - |Row| == n, |Column| == 1
            //  - |Row| == 1, |Column| == n
            //- If |Row| == |Column| == 1,
            //  each element of String is display in a new textline.
            //- If multiple positions or specified, the number of Strings
            //  must match the number of positions, i.e.:
            //  - Either |String| == n (each string is displayed at the
            //                          corresponding position),
            //  - or     |String| == 1 (The string is displayed n times).
            //
            //
            //Convert the parameters for disp_text.
            if ((int)((new HTuple(hv_Row_COPY_INP_TMP.TupleEqual(new HTuple()))).TupleOr(
                new HTuple(hv_Column_COPY_INP_TMP.TupleEqual(new HTuple())))) != 0)
            {

                hv_Color_COPY_INP_TMP.Dispose();
                hv_Column_COPY_INP_TMP.Dispose();
                hv_CoordSystem_COPY_INP_TMP.Dispose();
                hv_Row_COPY_INP_TMP.Dispose();
                hv_GenParamName.Dispose();
                hv_GenParamValue.Dispose();

                return;
            }
            if ((int)(new HTuple(hv_Row_COPY_INP_TMP.TupleEqual(-1))) != 0)
            {
                hv_Row_COPY_INP_TMP.Dispose();
                hv_Row_COPY_INP_TMP = 12;
            }
            if ((int)(new HTuple(hv_Column_COPY_INP_TMP.TupleEqual(-1))) != 0)
            {
                hv_Column_COPY_INP_TMP.Dispose();
                hv_Column_COPY_INP_TMP = 12;
            }
            //
            //Convert the parameter Box to generic parameters.
            hv_GenParamName.Dispose();
            hv_GenParamName = new HTuple();
            hv_GenParamValue.Dispose();
            hv_GenParamValue = new HTuple();
            if ((int)(new HTuple((new HTuple(hv_Box.TupleLength())).TupleGreater(0))) != 0)
            {
                if ((int)(new HTuple(((hv_Box.TupleSelect(0))).TupleEqual("false"))) != 0)
                {
                    //Display no box
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_GenParamName = hv_GenParamName.TupleConcat(
                                "box");
                            hv_GenParamName.Dispose();
                            hv_GenParamName = ExpTmpLocalVar_GenParamName;
                        }
                    }
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_GenParamValue = hv_GenParamValue.TupleConcat(
                                "false");
                            hv_GenParamValue.Dispose();
                            hv_GenParamValue = ExpTmpLocalVar_GenParamValue;
                        }
                    }
                }
                else if ((int)(new HTuple(((hv_Box.TupleSelect(0))).TupleNotEqual("true"))) != 0)
                {
                    //Set a color other than the default.
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_GenParamName = hv_GenParamName.TupleConcat(
                                "box_color");
                            hv_GenParamName.Dispose();
                            hv_GenParamName = ExpTmpLocalVar_GenParamName;
                        }
                    }
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_GenParamValue = hv_GenParamValue.TupleConcat(
                                hv_Box.TupleSelect(0));
                            hv_GenParamValue.Dispose();
                            hv_GenParamValue = ExpTmpLocalVar_GenParamValue;
                        }
                    }
                }
            }
            if ((int)(new HTuple((new HTuple(hv_Box.TupleLength())).TupleGreater(1))) != 0)
            {
                if ((int)(new HTuple(((hv_Box.TupleSelect(1))).TupleEqual("false"))) != 0)
                {
                    //Display no shadow.
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_GenParamName = hv_GenParamName.TupleConcat(
                                "shadow");
                            hv_GenParamName.Dispose();
                            hv_GenParamName = ExpTmpLocalVar_GenParamName;
                        }
                    }
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_GenParamValue = hv_GenParamValue.TupleConcat(
                                "false");
                            hv_GenParamValue.Dispose();
                            hv_GenParamValue = ExpTmpLocalVar_GenParamValue;
                        }
                    }
                }
                else if ((int)(new HTuple(((hv_Box.TupleSelect(1))).TupleNotEqual("true"))) != 0)
                {
                    //Set a shadow color other than the default.
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_GenParamName = hv_GenParamName.TupleConcat(
                                "shadow_color");
                            hv_GenParamName.Dispose();
                            hv_GenParamName = ExpTmpLocalVar_GenParamName;
                        }
                    }
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        {
                            HTuple
                              ExpTmpLocalVar_GenParamValue = hv_GenParamValue.TupleConcat(
                                hv_Box.TupleSelect(1));
                            hv_GenParamValue.Dispose();
                            hv_GenParamValue = ExpTmpLocalVar_GenParamValue;
                        }
                    }
                }
            }
            //Restore default CoordSystem behavior.
            if ((int)(new HTuple(hv_CoordSystem_COPY_INP_TMP.TupleNotEqual("window"))) != 0)
            {
                hv_CoordSystem_COPY_INP_TMP.Dispose();
                hv_CoordSystem_COPY_INP_TMP = "image";
            }
            //
            if ((int)(new HTuple(hv_Color_COPY_INP_TMP.TupleEqual(""))) != 0)
            {
                //disp_text does not accept an empty string for Color.
                hv_Color_COPY_INP_TMP.Dispose();
                hv_Color_COPY_INP_TMP = new HTuple();
            }
            //
            HOperatorSet.DispText(hv_WindowHandle, hv_String, hv_CoordSystem_COPY_INP_TMP,
                hv_Row_COPY_INP_TMP, hv_Column_COPY_INP_TMP, hv_Color_COPY_INP_TMP, hv_GenParamName,
                hv_GenParamValue);

            hv_Color_COPY_INP_TMP.Dispose();
            hv_Column_COPY_INP_TMP.Dispose();
            hv_CoordSystem_COPY_INP_TMP.Dispose();
            hv_Row_COPY_INP_TMP.Dispose();
            hv_GenParamName.Dispose();
            hv_GenParamValue.Dispose();

            return;
        }

        private void accuracyMessBtn_Click(object sender, EventArgs e)
        {
            
            openFileDialog1.Filter = "JPG文件|*.jpg|BMP文件|*.bmp|PNG文件|*.png";
            openFileDialog1.RestoreDirectory = true;
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                match_pic = openFileDialog1.FileName;
                LogBox.Clear();
                try
                {
                    get_standarlization(match_pic);
                }
                catch (Exception error)
                {
                    MessageBox.Show(error.Message);
                }
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
    
        }
        public void ReadLog(string log)
        {
            LogBox.AppendText(log + "\r\n");
       
        }

        private void hWindowControl1_HMouseMove(object sender, HMouseEventArgs e)
        {
            
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "BMP文件|*.bmp|JPG文件|*.jpg|PNG文件|*.png";
            openFileDialog1.RestoreDirectory = true;
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                ImagePath_Object = openFileDialog1.FileName;
                //read_image (Image, 'pads.png')
                // Local iconic variables
                HObject ho_GrayImage, ho_getPreprocessImage = null;
                HObject ho_SelectedRegions1, ho_outside_SelectedRegions;
                HObject ho_Ring_ConnectedRegions;

                // Local control variables 

                HTuple hv_imageFileRoad = new HTuple(), hv_Selected = new HTuple();
                HTuple hv_image_Number = new HTuple(), hv_Width = new HTuple();
                HTuple hv_Height = new HTuple(), hv_imageWidth = new HTuple();
                HTuple hv_imageHeight = new HTuple(), hv_Inner_circle_Number = new HTuple();
                HTuple hv_Inner_circle_Area = new HTuple(), hv_Inner_circle_Row = new HTuple();
                HTuple hv_Inner_circle_Column = new HTuple(), hv_Mean_radius_inner_circle = new HTuple();
                HTuple hv_number_of_Inner_Circle = new HTuple(), hv_area_of_Inner_Cirlce = new HTuple();
                HTuple hv_meanRadius_of_Inner_Circle = new HTuple(), hv_row_of_Inner_Circle = new HTuple();
                HTuple hv_column_of_Inner_Circle = new HTuple(), hv_save_Inner_Circle_Name = new HTuple();
                HTuple hv_outside_Number = new HTuple(), hv_outside_Row = new HTuple();
                HTuple hv_outside_Column = new HTuple(), hv_outside_Radius = new HTuple();
                HTuple hv_outside_Area = new HTuple(), hv_number_Of_Outside_Circle = new HTuple();
                HTuple hv_row_Of_Outside_Circle = new HTuple(), hv_column_Of_Outside_Circle = new HTuple();
                HTuple hv_radius_Of_Outside_Circle = new HTuple(), hv_area_Of_Outside_Circle = new HTuple();
                HTuple hv_save_Outside_Circle_Name = new HTuple(), hv_max_ring_width = new HTuple();
                HTuple hv_min_ring_width = new HTuple(), hv_average_ring_width = new HTuple();
                HTuple hv_the_Max_Width_of_Ring = new HTuple(), hv_the_Min_Width_of_Ring = new HTuple();
                HTuple hv_the_Average_Width_of_Ring = new HTuple(), hv_save_Calculate_Ring_Name = new HTuple();
                // Initialize local and output iconic variables 
                HOperatorSet.GenEmptyObj(out ho_GrayImage);
                HOperatorSet.GenEmptyObj(out ho_getPreprocessImage);
                HOperatorSet.GenEmptyObj(out ho_SelectedRegions1);
                HOperatorSet.GenEmptyObj(out ho_outside_SelectedRegions);
                HOperatorSet.GenEmptyObj(out ho_Ring_ConnectedRegions);
                //预处理
                hv_imageFileRoad.Dispose();
                hv_imageFileRoad = ImagePath_Object;
                hv_Selected.Dispose();
                try
                {
                    HOperatorSet.TupleStrBitSelect(hv_imageFileRoad, 35, out hv_Selected);
                    hv_image_Number.Dispose();
                    hv_image_Number = new HTuple(hv_Selected);
                    ho_GrayImage.Dispose(); hv_Width.Dispose(); hv_Height.Dispose();
                    In_Image_gray(out ho_GrayImage, hv_imageFileRoad, out hv_Width, out hv_Height);
                    ReadLog("灰度图获取成功！");

                    ho_getPreprocessImage.Dispose();
                    ho_getPreprocessImage = new HObject(ho_GrayImage);
                    hv_imageWidth.Dispose();
                    hv_imageWidth = new HTuple(hv_Width);
                    hv_imageHeight.Dispose();
                    hv_imageHeight = new HTuple(hv_Height);
                    //计算内圆
                    ho_SelectedRegions1.Dispose(); hv_Inner_circle_Number.Dispose(); hv_Inner_circle_Area.Dispose(); hv_Inner_circle_Row.Dispose(); hv_Inner_circle_Column.Dispose(); hv_Mean_radius_inner_circle.Dispose();
                    Calu_Inner_Circle(ho_getPreprocessImage, out ho_SelectedRegions1, out hv_Inner_circle_Number,
                        out hv_Inner_circle_Area, out hv_Inner_circle_Row, out hv_Inner_circle_Column,
                        out hv_Mean_radius_inner_circle);
                    ReadLog("内圆获取成功！");
                    ReadLog("目标数为：" + hv_Inner_circle_Number);

                    hv_number_of_Inner_Circle.Dispose();
                    hv_number_of_Inner_Circle = new HTuple(hv_Inner_circle_Number);
                    hv_area_of_Inner_Cirlce.Dispose();
                    hv_area_of_Inner_Cirlce = new HTuple(hv_Inner_circle_Area);
                    hv_meanRadius_of_Inner_Circle.Dispose();
                    hv_meanRadius_of_Inner_Circle = new HTuple(hv_Mean_radius_inner_circle);
                    hv_row_of_Inner_Circle.Dispose();
                    hv_row_of_Inner_Circle = new HTuple(hv_Inner_circle_Row);
                    hv_column_of_Inner_Circle.Dispose();
                    hv_column_of_Inner_Circle = new HTuple(hv_Inner_circle_Column);
                    hv_save_Inner_Circle_Name.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_save_Inner_Circle_Name = "innercircle" + hv_image_Number;
                    }
                    Display_Information(hv_imageWidth, hv_imageHeight, hv_number_of_Inner_Circle,
                        hv_row_of_Inner_Circle, hv_column_of_Inner_Circle, hv_meanRadius_of_Inner_Circle,
                        hv_save_Inner_Circle_Name);
                    ReadLog("内圆信息获取成功！");
                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.CloseWindow(HDevWindowStack.Pop());
                    }

                    //计算外圆
                    ho_outside_SelectedRegions.Dispose(); hv_outside_Number.Dispose(); hv_outside_Row.Dispose(); hv_outside_Column.Dispose(); hv_outside_Radius.Dispose(); hv_outside_Area.Dispose();
                    Calu_outside_Circle(ho_getPreprocessImage, out ho_outside_SelectedRegions, out hv_outside_Number,
                        out hv_outside_Row, out hv_outside_Column, out hv_outside_Radius, out hv_outside_Area);
                    ReadLog("外轮廓获取成功！");
                    hv_number_Of_Outside_Circle.Dispose();
                    hv_number_Of_Outside_Circle = new HTuple(hv_outside_Number);
                    hv_row_Of_Outside_Circle.Dispose();
                    hv_row_Of_Outside_Circle = new HTuple(hv_outside_Row);
                    hv_column_Of_Outside_Circle.Dispose();
                    hv_column_Of_Outside_Circle = new HTuple(hv_outside_Column);
                    hv_radius_Of_Outside_Circle.Dispose();
                    hv_radius_Of_Outside_Circle = new HTuple(hv_outside_Radius);
                    hv_area_Of_Outside_Circle.Dispose();
                    hv_area_Of_Outside_Circle = new HTuple(hv_outside_Area);
                    hv_save_Outside_Circle_Name.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_save_Outside_Circle_Name = "outsideCircle" + hv_image_Number;
                    }
                    Display_Information(hv_Width, hv_Height, hv_number_Of_Outside_Circle, hv_row_Of_Outside_Circle,
                        hv_column_Of_Outside_Circle, hv_radius_Of_Outside_Circle, hv_save_Outside_Circle_Name);
                    ReadLog("外轮廓信息获取成功！");
                    //计算圆环
                    ho_Ring_ConnectedRegions.Dispose(); hv_max_ring_width.Dispose(); hv_min_ring_width.Dispose(); hv_average_ring_width.Dispose();
                    Calcu_Ring_Width(ho_outside_SelectedRegions, ho_getPreprocessImage, out ho_Ring_ConnectedRegions,
                        hv_meanRadius_of_Inner_Circle, hv_area_of_Inner_Cirlce, out hv_max_ring_width,
                        out hv_min_ring_width, out hv_average_ring_width);
                    ReadLog("圆环获取成功！");
                    hv_the_Max_Width_of_Ring.Dispose();
                    hv_the_Max_Width_of_Ring = new HTuple(hv_max_ring_width);
                    hv_the_Min_Width_of_Ring.Dispose();
                    hv_the_Min_Width_of_Ring = new HTuple(hv_min_ring_width);
                    hv_the_Average_Width_of_Ring.Dispose();
                    hv_the_Average_Width_of_Ring = new HTuple(hv_average_ring_width);
                    hv_save_Calculate_Ring_Name.Dispose();
                    using (HDevDisposeHelper dh = new HDevDisposeHelper())
                    {
                        hv_save_Calculate_Ring_Name = "Ring" + hv_image_Number;
                    }
                    Display_Ring(hv_imageWidth, hv_imageHeight, hv_number_Of_Outside_Circle, hv_row_Of_Outside_Circle,
                        hv_column_Of_Outside_Circle, hv_radius_Of_Outside_Circle, hv_row_of_Inner_Circle,
                        hv_column_of_Inner_Circle, hv_meanRadius_of_Inner_Circle, hv_the_Max_Width_of_Ring,
                        hv_the_Average_Width_of_Ring, hv_save_Calculate_Ring_Name);
                    ReadLog("圆环信息获取成功！");
           
                    for (int i = 0; i < hv_Inner_circle_Area.Length; i++)
                    {
                        string message = "内接圆" + (i + 1).ToString() + "   坐标为：(" + hv_Inner_circle_Row[i] + "," + hv_Inner_circle_Column[i] + ") " + "半径为：" + hv_meanRadius_of_Inner_Circle[i];
                        messagelist.Add(message);
                        string message1 = "外轮廓" + (i + 1).ToString() + "   坐标为：(" + hv_outside_Row[i] + "," + hv_outside_Column[i] + ") " + "半径为：" + hv_outside_Radius[i];
                        messagelist.Add(message1);
                        string message2 = "圆环最大宽度：" + hv_max_ring_width[i] + "  最小宽度：" + hv_min_ring_width[i] + "  平均宽度：" + hv_average_ring_width[i];
                        messagelist.Add(message2);
                        
                    }

                    if (HDevWindowStack.IsOpen())
                    {
                        HOperatorSet.DispObj(ho_GrayImage, HDevWindowStack.GetActive());
                    }
                    HOperatorSet.GetImageSize(ho_outside_SelectedRegions, out hv_Width, out hv_Height);

                    ho_GrayImage.Dispose();
                    ho_getPreprocessImage.Dispose();
                    ho_SelectedRegions1.Dispose();
                    ho_outside_SelectedRegions.Dispose();
                    ho_Ring_ConnectedRegions.Dispose();

                    hv_imageFileRoad.Dispose();
                    hv_Selected.Dispose();
                    hv_image_Number.Dispose();
                    hv_Width.Dispose();
                    hv_Height.Dispose();
                    hv_imageWidth.Dispose();
                    hv_imageHeight.Dispose();
                    hv_Inner_circle_Number.Dispose();
                    hv_Inner_circle_Area.Dispose();
                    hv_Inner_circle_Row.Dispose();
                    hv_Inner_circle_Column.Dispose();
                    hv_Mean_radius_inner_circle.Dispose();
                    hv_number_of_Inner_Circle.Dispose();
                    hv_area_of_Inner_Cirlce.Dispose();
                    hv_meanRadius_of_Inner_Circle.Dispose();
                    hv_row_of_Inner_Circle.Dispose();
                    hv_column_of_Inner_Circle.Dispose();
                    hv_save_Inner_Circle_Name.Dispose();
                    hv_outside_Number.Dispose();
                    hv_outside_Row.Dispose();
                    hv_outside_Column.Dispose();
                    hv_outside_Radius.Dispose();
                    hv_outside_Area.Dispose();
                    hv_number_Of_Outside_Circle.Dispose();
                    hv_row_Of_Outside_Circle.Dispose();
                    hv_column_Of_Outside_Circle.Dispose();
                    hv_radius_Of_Outside_Circle.Dispose();
                    hv_area_Of_Outside_Circle.Dispose();
                    hv_save_Outside_Circle_Name.Dispose();
                    hv_max_ring_width.Dispose();
                    hv_min_ring_width.Dispose();
                    hv_average_ring_width.Dispose();
                    hv_the_Max_Width_of_Ring.Dispose();
                    hv_the_Min_Width_of_Ring.Dispose();
                    hv_the_Average_Width_of_Ring.Dispose();
                    hv_save_Calculate_Ring_Name.Dispose();
                    
                }
                catch (Exception error)
                {
                    //MessageBox.Show(error.Message);
                }
            }

        }
        public void Calcu_Ring_Width(HObject ho_outside_SelectedRegions, HObject ho_GrayImage,
        out HObject ho_Ring_ConnectedRegions, HTuple hv_Mean_radius_inner_circle, HTuple hv_Area,
        out HTuple hv_max_ring_width, out HTuple hv_min_ring_width, out HTuple hv_average_ring_width)
        {




            // Local iconic variables 

            HObject ho_Regions3, ho_SelectedRegions3;

            // Local control variables 

            HTuple hv_Row5 = new HTuple(), hv_Column5 = new HTuple();
            HTuple hv_max_cylindrical_Radius = new HTuple(), hv_Row6 = new HTuple();
            HTuple hv_Column6 = new HTuple(), hv_min_cylindrical_Radius = new HTuple();
            HTuple hv_Area1 = new HTuple(), hv_Row7 = new HTuple();
            HTuple hv_Column7 = new HTuple(), hv_Mean_radius_cylindrical_circle = new HTuple();
            HTuple hv_Area_ring = new HTuple(), hv_Row9 = new HTuple();
            HTuple hv_Column9 = new HTuple();
            // Initialize local and output iconic variables 
            HOperatorSet.GenEmptyObj(out ho_Ring_ConnectedRegions);
            HOperatorSet.GenEmptyObj(out ho_Regions3);
            HOperatorSet.GenEmptyObj(out ho_SelectedRegions3);
            hv_max_ring_width = new HTuple();
            hv_min_ring_width = new HTuple();
            hv_average_ring_width = new HTuple();
            //圆环的最大，最小，平均宽度
            hv_Row5.Dispose(); hv_Column5.Dispose(); hv_max_cylindrical_Radius.Dispose();
            HOperatorSet.SmallestCircle(ho_outside_SelectedRegions, out hv_Row5, out hv_Column5,
                out hv_max_cylindrical_Radius);
            hv_Row6.Dispose(); hv_Column6.Dispose(); hv_min_cylindrical_Radius.Dispose();
            HOperatorSet.InnerCircle(ho_outside_SelectedRegions, out hv_Row6, out hv_Column6,
                out hv_min_cylindrical_Radius);
            hv_max_ring_width.Dispose();
            using (HDevDisposeHelper dh = new HDevDisposeHelper())
            {
                hv_max_ring_width = hv_max_cylindrical_Radius - hv_Mean_radius_inner_circle;
            }
            hv_min_ring_width.Dispose();
            using (HDevDisposeHelper dh = new HDevDisposeHelper())
            {
                hv_min_ring_width = hv_min_cylindrical_Radius - hv_Mean_radius_inner_circle;
            }
            //圆环的平均厚度
            hv_Area1.Dispose(); hv_Row7.Dispose(); hv_Column7.Dispose();
            HOperatorSet.AreaCenter(ho_outside_SelectedRegions, out hv_Area1, out hv_Row7,
                out hv_Column7);
            hv_Mean_radius_cylindrical_circle.Dispose();
            using (HDevDisposeHelper dh = new HDevDisposeHelper())
            {
                hv_Mean_radius_cylindrical_circle = ((hv_Area1 / 3.1415926)).TupleSqrt()
                    ;
            }
            //average_ring_width := Mean_radius_cylindrical_circle - Mean_radius_inner_circle

            if (HDevWindowStack.IsOpen())
            {
                HOperatorSet.SetDraw(HDevWindowStack.GetActive(), "margin");
            }
            ho_Regions3.Dispose();
            HOperatorSet.Threshold(ho_GrayImage, out ho_Regions3, 151, 255);
            ho_Ring_ConnectedRegions.Dispose();
            HOperatorSet.Connection(ho_Regions3, out ho_Ring_ConnectedRegions);
            //8.9修改
            ho_SelectedRegions3.Dispose();
            HOperatorSet.SelectShape(ho_Ring_ConnectedRegions, out ho_SelectedRegions3, "area",
                "and", 1541.67, 4532.41);
            hv_Area_ring.Dispose(); hv_Row9.Dispose(); hv_Column9.Dispose();
            HOperatorSet.AreaCenter(ho_SelectedRegions3, out hv_Area_ring, out hv_Row9, out hv_Column9);
            hv_average_ring_width.Dispose();
            using (HDevDisposeHelper dh = new HDevDisposeHelper())
            {
                hv_average_ring_width = ((((hv_Area_ring + hv_Area) / 3.1415926)).TupleSqrt()
                    ) - hv_Mean_radius_inner_circle;
            }
            ho_Regions3.Dispose();
            ho_SelectedRegions3.Dispose();

            hv_Row5.Dispose();
            hv_Column5.Dispose();
            hv_max_cylindrical_Radius.Dispose();
            hv_Row6.Dispose();
            hv_Column6.Dispose();
            hv_min_cylindrical_Radius.Dispose();
            hv_Area1.Dispose();
            hv_Row7.Dispose();
            hv_Column7.Dispose();
            hv_Mean_radius_cylindrical_circle.Dispose();
            hv_Area_ring.Dispose();
            hv_Row9.Dispose();
            hv_Column9.Dispose();

            return;
        }



        // Short Description: 输入灰度图，输出内圆的面积，圆心，和半径 
        public void Calu_Inner_Circle(HObject ho_GrayImage, out HObject ho_SelectedRegions1,
            out HTuple hv_Inner_circle_Number, out HTuple hv_Inner_circle_Area, out HTuple hv_Inner_circle_Row,
            out HTuple hv_Inner_circle_Column, out HTuple hv_Mean_radius_inner_circle)
        {



            // Local iconic variables 

            HObject ho_Regions, ho_RegionFillUp, ho_ConnectedRegions;
            HObject ho_SelectedRegions;
            // Initialize local and output iconic variables 
            HOperatorSet.GenEmptyObj(out ho_SelectedRegions1);
            HOperatorSet.GenEmptyObj(out ho_Regions);
            HOperatorSet.GenEmptyObj(out ho_RegionFillUp);
            HOperatorSet.GenEmptyObj(out ho_ConnectedRegions);
            HOperatorSet.GenEmptyObj(out ho_SelectedRegions);
            hv_Inner_circle_Number = new HTuple();
            hv_Inner_circle_Area = new HTuple();
            hv_Inner_circle_Row = new HTuple();
            hv_Inner_circle_Column = new HTuple();
            hv_Mean_radius_inner_circle = new HTuple();
            ho_Regions.Dispose();
            HOperatorSet.Threshold(ho_GrayImage, out ho_Regions, 0, 0);
            ho_RegionFillUp.Dispose();
            HOperatorSet.FillUp(ho_Regions, out ho_RegionFillUp);
            ho_ConnectedRegions.Dispose();
            HOperatorSet.Connection(ho_RegionFillUp, out ho_ConnectedRegions);
            ho_SelectedRegions.Dispose();
            HOperatorSet.SelectShape(ho_ConnectedRegions, out ho_SelectedRegions, "area",
                "and", 190.48, 2476.19);
            ho_SelectedRegions1.Dispose();
            HOperatorSet.SelectShape(ho_SelectedRegions, out ho_SelectedRegions1, "circularity",
                "and", 0.9, 1);
            hv_Inner_circle_Number.Dispose();
            HOperatorSet.CountObj(ho_SelectedRegions1, out hv_Inner_circle_Number);
            //内圆面积,通过面积计算内圆的平均半径
            hv_Inner_circle_Area.Dispose(); hv_Inner_circle_Row.Dispose(); hv_Inner_circle_Column.Dispose();
            HOperatorSet.AreaCenter(ho_SelectedRegions1, out hv_Inner_circle_Area, out hv_Inner_circle_Row,
                out hv_Inner_circle_Column);
            hv_Mean_radius_inner_circle.Dispose();
            using (HDevDisposeHelper dh = new HDevDisposeHelper())
            {
                hv_Mean_radius_inner_circle = ((hv_Inner_circle_Area / 3.1415926)).TupleSqrt()
                    ;
            }
            ho_Regions.Dispose();
            ho_RegionFillUp.Dispose();
            ho_ConnectedRegions.Dispose();
            ho_SelectedRegions.Dispose();


            return;
        }

        // Short Description: Calculate the information about the outer circle 
        public void Calu_outside_Circle(HObject ho_GrayImage, out HObject ho_outside_SelectedRegions,
            out HTuple hv_outside_Number, out HTuple hv_outside_Row, out HTuple hv_outside_Column,
            out HTuple hv_outside_Radius, out HTuple hv_outside_Area)
        {

            // Local iconic variables 

            HObject ho_Regions1, ho_RegionFillUp1, ho_ConnectedRegions1;
            HObject ho_Contours1, ho_ContCircle;

            // Local control variables 

            HTuple hv_Row2 = new HTuple(), hv_Column2 = new HTuple();
            HTuple hv_StartPhi1 = new HTuple(), hv_EndPhi1 = new HTuple();
            HTuple hv_PointOrder1 = new HTuple(), hv_Mean_radius_outside_circle = new HTuple();
            // Initialize local and output iconic variables 
            HOperatorSet.GenEmptyObj(out ho_outside_SelectedRegions);
            HOperatorSet.GenEmptyObj(out ho_Regions1);
            HOperatorSet.GenEmptyObj(out ho_RegionFillUp1);
            HOperatorSet.GenEmptyObj(out ho_ConnectedRegions1);
            HOperatorSet.GenEmptyObj(out ho_Contours1);
            HOperatorSet.GenEmptyObj(out ho_ContCircle);
            hv_outside_Number = new HTuple();
            hv_outside_Row = new HTuple();
            hv_outside_Column = new HTuple();
            hv_outside_Radius = new HTuple();
            hv_outside_Area = new HTuple();
            //外圆轮廓 外圆半径 圆心
            ho_Regions1.Dispose();
            HOperatorSet.Threshold(ho_GrayImage, out ho_Regions1, 65, 255);
            ho_RegionFillUp1.Dispose();
            HOperatorSet.FillUp(ho_Regions1, out ho_RegionFillUp1);
            ho_ConnectedRegions1.Dispose();
            HOperatorSet.Connection(ho_RegionFillUp1, out ho_ConnectedRegions1);
            ho_outside_SelectedRegions.Dispose();
            HOperatorSet.SelectShape(ho_ConnectedRegions1, out ho_outside_SelectedRegions,
                "area", "and", 5500, 9634.15);
            hv_outside_Number.Dispose();
            HOperatorSet.CountObj(ho_outside_SelectedRegions, out hv_outside_Number);
            ho_Contours1.Dispose();
            HOperatorSet.GenContourRegionXld(ho_outside_SelectedRegions, out ho_Contours1,
                "border");
            hv_Row2.Dispose(); hv_Column2.Dispose(); hv_outside_Radius.Dispose(); hv_StartPhi1.Dispose(); hv_EndPhi1.Dispose(); hv_PointOrder1.Dispose();
            HOperatorSet.FitCircleContourXld(ho_Contours1, "algebraic", -1, 0, 0, 3, 2, out hv_Row2,
                out hv_Column2, out hv_outside_Radius, out hv_StartPhi1, out hv_EndPhi1,
                out hv_PointOrder1);
            ho_ContCircle.Dispose();
            HOperatorSet.GenCircleContourXld(out ho_ContCircle, hv_Row2, hv_Column2, hv_outside_Radius,
                hv_StartPhi1, hv_StartPhi1, "positive", 1);
            hv_outside_Area.Dispose(); hv_outside_Row.Dispose(); hv_outside_Column.Dispose();
            HOperatorSet.AreaCenter(ho_outside_SelectedRegions, out hv_outside_Area, out hv_outside_Row,
                out hv_outside_Column);
            hv_Mean_radius_outside_circle.Dispose();
            using (HDevDisposeHelper dh = new HDevDisposeHelper())
            {
                hv_Mean_radius_outside_circle = ((hv_outside_Area / 3.1415926)).TupleSqrt()
                    ;
            }
            ho_Regions1.Dispose();
            ho_RegionFillUp1.Dispose();
            ho_ConnectedRegions1.Dispose();
            ho_Contours1.Dispose();
            ho_ContCircle.Dispose();

            hv_Row2.Dispose();
            hv_Column2.Dispose();
            hv_StartPhi1.Dispose();
            hv_EndPhi1.Dispose();
            hv_PointOrder1.Dispose();
            hv_Mean_radius_outside_circle.Dispose();

            return;
        }



        // Short Description: 显示圆和圆心的半径，面积和圆心 
        public void Display_Information(HTuple hv_Width, HTuple hv_Height, HTuple hv_Circle_Number,
            HTuple hv_Row, HTuple hv_Column, HTuple hv_Circle_radius, HTuple hv_Save_Image_Name)
        {

            // Local iconic variables 

            HObject ho_File_Image_Name;

            // Local control variables 

            HTuple hv_WindowHandle_d = new HTuple(), hv_Index = new HTuple();
            // Initialize local and output iconic variables 
            HOperatorSet.GenEmptyObj(out ho_File_Image_Name);
            if (HDevWindowStack.IsOpen())
            {
                HOperatorSet.CloseWindow(HDevWindowStack.Pop());
            }
            
            HOperatorSet.SetWindowAttr("background_color", "black");
            HOperatorSet.OpenWindow(0, 0, hWindowControl1.Width, hWindowControl1.Height, hWindowControl1.HalconWindow, "", "", out hv_WindowHandle_d);
            //HOperatorSet.OpenWindow(0, 0, hv_Width, hv_Height, 0, "visible", "", out hv_WindowHandle1);
            HDevWindowStack.Push(hv_WindowHandle_d);
            HTuple end_val2 = hv_Circle_Number - 1;
            HTuple step_val2 = 1;
            for (hv_Index = 0; hv_Index.Continue(end_val2, step_val2); hv_Index = hv_Index.TupleAdd(step_val2))
            {
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    HOperatorSet.DispCircle(hv_WindowHandle_d, hv_Row.TupleSelect(hv_Index), hv_Column.TupleSelect(
                        hv_Index), hv_Circle_radius.TupleSelect(hv_Index));
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.SetColor(HDevWindowStack.GetActive(), "white");
                }
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    HOperatorSet.SetTposition(hv_WindowHandle_d, (hv_Row.TupleSelect(hv_Index)) - (hv_Circle_radius.TupleSelect(
                        hv_Index)), (hv_Column.TupleSelect(hv_Index)) - (hv_Circle_radius.TupleSelect(
                        hv_Index)));
                }
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    HOperatorSet.WriteString(hv_WindowHandle_d, (("center:" + (hv_Row.TupleSelect(
                        hv_Index))) + new HTuple(",")) + (hv_Column.TupleSelect(hv_Index)));
                }
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    HOperatorSet.SetTposition(hv_WindowHandle_d, ((hv_Row.TupleSelect(hv_Index)) - (hv_Circle_radius.TupleSelect(
                        hv_Index))) + 30, (hv_Column.TupleSelect(hv_Index)) - (hv_Circle_radius.TupleSelect(
                        hv_Index)));
                }
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    HOperatorSet.WriteString(hv_WindowHandle_d, "center:" + (hv_Circle_radius.TupleSelect(
                        hv_Index)));
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.SetColor(HDevWindowStack.GetActive(), "blue");
                }
            }
            ho_File_Image_Name.Dispose();
            //HOperatorSet.DumpWindowImage(out ho_File_Image_Name, hv_WindowHandle_d);
            //HOperatorSet.WriteImage(ho_File_Image_Name, "tiff", 0, hv_Save_Image_Name);
            ho_File_Image_Name.Dispose();

            hv_WindowHandle_d.Dispose();
            hv_Index.Dispose();

            return;
        }

        // Short Description: 输入图像增强，灰度化，输出图像的宽和高，以及灰度图 
        public void In_Image_gray(out HObject ho_GrayImage, HTuple hv_Image_road, out HTuple hv_Width,
            out HTuple hv_Height)
        {

            // Local iconic variables 

            HObject ho_Image01, ho_ImageEmphasize;
            // Initialize local and output iconic variables 
            HOperatorSet.GenEmptyObj(out ho_GrayImage);
            HOperatorSet.GenEmptyObj(out ho_Image01);
            HOperatorSet.GenEmptyObj(out ho_ImageEmphasize);
            hv_Width = new HTuple();
            hv_Height = new HTuple();
            ho_Image01.Dispose();
            HOperatorSet.ReadImage(out ho_Image01, hv_Image_road);
            hv_Width.Dispose(); hv_Height.Dispose();
            HOperatorSet.GetImageSize(ho_Image01, out hv_Width, out hv_Height);
            HOperatorSet.SetPart(this.hWindowControl1.HalconWindow, 0, 0, hv_Height - 1, hv_Width - 1);
            //图像增强 滤波
            ho_ImageEmphasize.Dispose();
            HOperatorSet.Emphasize(ho_Image01, out ho_ImageEmphasize, hv_Width, hv_Height,
                1);
            //blob分析 求区域
            ho_GrayImage.Dispose();
            HOperatorSet.Rgb1ToGray(ho_ImageEmphasize, out ho_GrayImage);
            ho_Image01.Dispose();
            ho_ImageEmphasize.Dispose();

            return;
        }

        public void Display_Ring(HTuple hv_Width, HTuple hv_Height, HTuple hv_outside_Number,
      HTuple hv_outside_Row, HTuple hv_outside_Column, HTuple hv_outside_Radius, HTuple hv_Inner_circle_Row,
      HTuple hv_Inner_circle_Column, HTuple hv_Mean_radius_inner_circle, HTuple hv_max_ring_width,
      HTuple hv_average_ring_width, HTuple hv_save_Calculate_Ring_Name)
        {

            // Local iconic variables 

            HObject ho_Image_Name;

            // Local control variables 

            HTuple hv_WindowHandle3 = new HTuple(), hv_Index = new HTuple();
            // Initialize local and output iconic variables 
            HOperatorSet.GenEmptyObj(out ho_Image_Name);
            if (HDevWindowStack.IsOpen())
            {
                HOperatorSet.CloseWindow(HDevWindowStack.Pop());
            }
            HOperatorSet.SetWindowAttr("background_color", "blue");
            HOperatorSet.OpenWindow(0, 0, hWindowControl1.Width, hWindowControl1.Height, hWindowControl1.HalconWindow, "", "", out hv_WindowHandle3);
            //HOperatorSet.OpenWindow(0, 0, hv_Width, hv_Height, 0, "visible", "", out hv_WindowHandle3);
            HDevWindowStack.Push(hv_WindowHandle3);
            HTuple end_val2 = hv_outside_Number - 1;
            HTuple step_val2 = 1;
            for (hv_Index = 0; hv_Index.Continue(end_val2, step_val2); hv_Index = hv_Index.TupleAdd(step_val2))
            {
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    HOperatorSet.DispCircle(hv_WindowHandle3, hv_outside_Row.TupleSelect(hv_Index),
                        hv_outside_Column.TupleSelect(hv_Index), hv_outside_Radius.TupleSelect(
                        hv_Index));
                }
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    HOperatorSet.DispCircle(hv_WindowHandle3, hv_Inner_circle_Row.TupleSelect(hv_Index),
                        hv_Inner_circle_Column.TupleSelect(hv_Index), hv_Mean_radius_inner_circle.TupleSelect(
                        hv_Index));
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.SetColor(HDevWindowStack.GetActive(), "white");
                }
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    HOperatorSet.SetTposition(hv_WindowHandle3, hv_outside_Row.TupleSelect(hv_Index),
                        hv_outside_Column.TupleSelect(hv_Index));
                }
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    HOperatorSet.WriteString(hv_WindowHandle3, "max_rin:" + (hv_max_ring_width.TupleSelect(
                        hv_Index)));
                }
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    HOperatorSet.SetTposition(hv_WindowHandle3, (hv_outside_Row.TupleSelect(hv_Index)) + 30,
                        hv_outside_Column.TupleSelect(hv_Index));
                }
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    HOperatorSet.WriteString(hv_WindowHandle3, "min_ring:" + (hv_max_ring_width.TupleSelect(
                        hv_Index)));
                }
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    HOperatorSet.SetTposition(hv_WindowHandle3, (hv_outside_Row.TupleSelect(hv_Index)) - 30,
                        hv_outside_Column.TupleSelect(hv_Index));
                }
                using (HDevDisposeHelper dh = new HDevDisposeHelper())
                {
                    HOperatorSet.WriteString(hv_WindowHandle3, "avg_ring:" + (hv_average_ring_width.TupleSelect(
                        hv_Index)));
                }
                if (HDevWindowStack.IsOpen())
                {
                    HOperatorSet.SetColor(HDevWindowStack.GetActive(), "blue");
                }
            }
            ho_Image_Name.Dispose();
            HOperatorSet.DumpWindowImage(out ho_Image_Name, hv_WindowHandle3);
            HOperatorSet.WriteImage(ho_Image_Name, "tiff", 0, hv_save_Calculate_Ring_Name);
            ho_Image_Name.Dispose();

            hv_WindowHandle3.Dispose();
            hv_Index.Dispose();

            return;
        }

        

        private void OutputMessBtn_Click(object sender, EventArgs e)
        {
            if (File.Exists(@fileName))
            {
                MessageBox.Show("文件已输出，请注意查收！");
            }
            else
            {
                MessageBox.Show("请输入文件！");
            }
        }

        private void EvaluateBtn_Click(object sender, EventArgs e)
        {
            // Local iconic variables 
            HObject ho_Image2, ho_Image, ho_Regions, ho_ConnectedRegions;
            HObject ho_RegionFillUp, ho_SelectedRegions, ho_RegionDifference;
            // Local control variables 

            HTuple hv_Width = new HTuple(), hv_Height = new HTuple();
            HTuple hv_O = new HTuple(), hv_RM1 = new HTuple(), hv_TM = new HTuple();
            HTuple hv_Ratio = new HTuple(), hv_WindowHandle = new HTuple();
            HTuple hv_Number = new HTuple(), hv_AreaW = new HTuple();
            HTuple hv_RowW = new HTuple(), hv_ColumnW = new HTuple();
            HTuple hv_WR = new HTuple(), hv_MatrixIDW = new HTuple();
            HTuple hv_TrueWR = new HTuple(), hv_MatrixMultIDW = new HTuple();
            HTuple hv_ValuesW = new HTuple(), hv_X = new HTuple();
            HTuple hv_Y = new HTuple(), hv_AreaN = new HTuple(), hv_RowN = new HTuple();
            HTuple hv_ColumnN = new HTuple(), hv_NR = new HTuple();
            HTuple hv_MatrixIDN = new HTuple(), hv_TrueNR = new HTuple();
            HTuple hv_MatrixMultIDN = new HTuple(), hv_ValuesN = new HTuple();
            HTuple hv_x = new HTuple(), hv_y = new HTuple(), hv_Row = new HTuple();
            HTuple hv_Column = new HTuple(), hv_Radius = new HTuple();
            HTuple hv_Row1 = new HTuple(), hv_Column1 = new HTuple();
            HTuple hv_Radius1 = new HTuple(), hv_Max = new HTuple();
            HTuple hv_Max1 = new HTuple(), hv_Row2 = new HTuple();
            HTuple hv_Column2 = new HTuple(), hv_Radius2 = new HTuple();
            HTuple hv_Row3 = new HTuple(), hv_Column3 = new HTuple();
            HTuple hv_Radius3 = new HTuple(), hv_Min = new HTuple();
            HTuple hv_Min1 = new HTuple(), hv_AverageR = new HTuple();
            HTuple hv_WindowHandle2 = new HTuple();
            // Initialize local and output iconic variables 
            HOperatorSet.GenEmptyObj(out ho_Image2);
            HOperatorSet.GenEmptyObj(out ho_Image);
            HOperatorSet.GenEmptyObj(out ho_Regions);
            HOperatorSet.GenEmptyObj(out ho_ConnectedRegions);
            HOperatorSet.GenEmptyObj(out ho_RegionFillUp);
            HOperatorSet.GenEmptyObj(out ho_SelectedRegions);
            HOperatorSet.GenEmptyObj(out ho_RegionDifference);

            try
            {
                try
                {
                    if (match_pic!=null || ImagePath_Object != null)
                    {
                        ho_Image2.Dispose();
                        HOperatorSet.ReadImage(out ho_Image2, match_pic);
                        ho_Image.Dispose();
                        HOperatorSet.ReadImage(out ho_Image, ImagePath_Object);
                        hv_Width.Dispose(); hv_Height.Dispose();
                        HOperatorSet.GetImageSize(ho_Image, out hv_Width, out hv_Height);
                        hv_O.Dispose(); hv_RM1.Dispose(); hv_TM.Dispose(); hv_Ratio.Dispose();
                        cal_checkerboard(ho_Image2, out hv_O, out hv_RM1, out hv_TM, out hv_Ratio);
                        if (HDevWindowStack.IsOpen())
                        {
                            HOperatorSet.CloseWindow(HDevWindowStack.Pop());
                        }
                        HOperatorSet.SetWindowAttr("background_color", "black");
                        HOperatorSet.OpenWindow(0, 0, hWindowControl1.Width, hWindowControl1.Height, hWindowControl1.HalconWindow, "", "", out hv_WindowHandle);
                        //HOperatorSet.OpenWindow(0, 0, hv_Width / 3, hv_Height / 3, 0, "visible", "", out hv_WindowHandle);
                        HDevWindowStack.Push(hv_WindowHandle);
                        //stop ()
                        //图像测量
                        ho_Regions.Dispose();
                        HOperatorSet.Threshold(ho_Image, out ho_Regions, 100, 255);
                        ho_ConnectedRegions.Dispose();
                        HOperatorSet.Connection(ho_Regions, out ho_ConnectedRegions);
                        ho_RegionFillUp.Dispose();
                        HOperatorSet.FillUp(ho_ConnectedRegions, out ho_RegionFillUp);
                        ho_SelectedRegions.Dispose();
                        HOperatorSet.SelectShape(ho_RegionFillUp, out ho_SelectedRegions, (new HTuple("area")).TupleConcat(
                            "circularity"), "and", (new HTuple(5000)).TupleConcat(0.9), (new HTuple(6500)).TupleConcat(
                            1));
                        hv_Number.Dispose();
                        HOperatorSet.CountObj(ho_SelectedRegions, out hv_Number);
                        if ((int)(new HTuple(hv_Number.TupleNotEqual(19))) != 0)
                        {
                            disp_message(hv_WindowHandle, "检测目标不完整", "window", 12, 12, "black",
                                "true");
                            // stop(...); only in hdevelop
                        }
                        //stop ()
                        //求外圆参数,
                        hv_AreaW.Dispose(); hv_RowW.Dispose(); hv_ColumnW.Dispose();
                        HOperatorSet.AreaCenter(ho_RegionFillUp, out hv_AreaW, out hv_RowW, out hv_ColumnW);
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            hv_WR.Dispose();
                            HOperatorSet.TupleSqrt(hv_AreaW / 3.1415, out hv_WR);
                        }
                        //像素坐标转实际坐标
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            hv_MatrixIDW.Dispose();
                            HOperatorSet.CreateMatrix(2, 19, hv_RowW.TupleConcat(hv_ColumnW), out hv_MatrixIDW);
                        }
                        hv_TrueWR.Dispose();
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            hv_TrueWR = hv_WR * hv_Ratio;
                        }
                        hv_MatrixMultIDW.Dispose();
                        HOperatorSet.MultMatrix(hv_RM1, hv_MatrixIDW, "AB", out hv_MatrixMultIDW);
                        hv_ValuesW.Dispose();
                        HOperatorSet.GetFullMatrix(hv_MatrixMultIDW, out hv_ValuesW);
                        hv_X.Dispose();
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            hv_X = ((hv_ValuesW.TupleSelectRange(
                                0, 18)) + (hv_O.TupleSelect(0))) * hv_Ratio;
                        }
                        hv_Y.Dispose();
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            hv_Y = ((hv_ValuesW.TupleSelectRange(
                                19, 37)) + (hv_O.TupleSelect(1))) * hv_Ratio;
                        }
                        //求内圆参数
                        ho_RegionDifference.Dispose();
                        HOperatorSet.Difference(ho_RegionFillUp, ho_ConnectedRegions, out ho_RegionDifference
                            );
                        hv_AreaN.Dispose(); hv_RowN.Dispose(); hv_ColumnN.Dispose();
                        HOperatorSet.AreaCenter(ho_RegionDifference, out hv_AreaN, out hv_RowN, out hv_ColumnN);
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            hv_NR.Dispose();
                            HOperatorSet.TupleSqrt(hv_AreaN / 3.1415, out hv_NR);
                        }
                        //像素坐标转实际坐标
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            hv_MatrixIDN.Dispose();
                            HOperatorSet.CreateMatrix(2, 19, hv_RowN.TupleConcat(hv_ColumnN), out hv_MatrixIDN);
                        }
                        hv_TrueNR.Dispose();
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            hv_TrueNR = hv_NR * hv_Ratio;
                        }
                        hv_MatrixMultIDN.Dispose();
                        HOperatorSet.MultMatrix(hv_RM1, hv_MatrixIDN, "AB", out hv_MatrixMultIDN);
                        hv_ValuesN.Dispose();
                        HOperatorSet.GetFullMatrix(hv_MatrixMultIDN, out hv_ValuesN);
                        hv_x.Dispose();
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            hv_x = ((((hv_ValuesN.TupleSelectRange(
                                0, 18)) + (hv_O.TupleSelect(1))) * hv_Ratio)).TupleString(".3f");
                        }
                        hv_y.Dispose();
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            hv_y = ((((hv_ValuesN.TupleSelectRange(
                                19, 37)) + (hv_O.TupleSelect(0))) * hv_Ratio)).TupleString(".3f");
                        }
                        LogBox.Clear();

                        //获取内圆、外部轮廓的半径及圆心以及圆环的最大、最小、平均厚度

                        int len = hv_X.Length;
                        HTuple[] InnerCircleN = new HTuple[len];
                        HTuple[] InnerCircleAVR = new HTuple[len];
                        HTuple[] CircleMax = new HTuple[len];
                        HTuple[] CircleMin = new HTuple[len];
                        HTuple[] OutSideW = new HTuple[len];
                        StreamWriter fileWriter = new StreamWriter(fileName, true, Encoding.ASCII);
                        fileWriter.WriteLine("Number,InnerCircle,OutsideCircle,InnerSet_x,InnerSet_x,OutsizeSet_x,OutsizeSet_y");
                        string MapSet;//大圆圆心坐标
                        string InnerSet;//小圆圆心坐标

                        for(int i = 0; i < hv_X.Length; i++)
                        {
                            ReadLog("圆"+(i+1).ToString() + "映射坐标为：" + "(" + hv_x[i] + "," + hv_y[i] + ")");
                            MapSet = hv_X[i] + "," + hv_Y[i];
                            InnerCircleN[i] = hv_TrueNR[i];
                            OutSideW[i] = hv_TrueWR[i];
                            //InnerCircleAVR[i] = hv_AverageR[i];
                            //CircleMax[i] = hv_Max[i];
                            //CircleMin[i] = hv_Min[i];
                            InnerSet =  hv_x[i]+","+ hv_y[i] ;
                            //MessageBox.Show("写文件前OK!");
                            fileWriter.Write("{0},{1},{2},{3},{4}", i, InnerCircleN[i], OutSideW[i],
                             MapSet, InnerSet);
                            fileWriter.Write("\r\n");//换下一列
                        }
                        fileWriter.Flush();
                        fileWriter.Close();


                        //最大最小值、平均厚度
                        hv_Row.Dispose(); hv_Column.Dispose(); hv_Radius.Dispose();
                        HOperatorSet.SmallestCircle(ho_RegionFillUp, out hv_Row, out hv_Column, out hv_Radius);
                        hv_Row1.Dispose(); hv_Column1.Dispose(); hv_Radius1.Dispose();
                        HOperatorSet.InnerCircle(ho_RegionDifference, out hv_Row1, out hv_Column1,
                            out hv_Radius1);
                        hv_Max.Dispose();
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            hv_Max = (hv_Radius - hv_Radius1) * hv_Ratio;
                        }
                        hv_Max1.Dispose();
                        HOperatorSet.TupleMax(hv_Max, out hv_Max1);
                        hv_Row2.Dispose(); hv_Column2.Dispose(); hv_Radius2.Dispose();
                        HOperatorSet.InnerCircle(ho_RegionFillUp, out hv_Row2, out hv_Column2, out hv_Radius2);
                        hv_Row3.Dispose(); hv_Column3.Dispose(); hv_Radius3.Dispose();
                        HOperatorSet.SmallestCircle(ho_RegionDifference, out hv_Row3, out hv_Column3,
                            out hv_Radius3);
                        hv_Min.Dispose();
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            hv_Min = (hv_Radius2 - hv_Radius3) * hv_Ratio;
                        }
                        hv_Min1.Dispose();
                        HOperatorSet.TupleMin(hv_Min, out hv_Min1);
                        hv_AverageR.Dispose();
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            hv_AverageR = hv_TrueWR - hv_TrueNR;
                        }

                        if (HDevWindowStack.IsOpen())
                        {
                            HOperatorSet.DispObj(ho_Image, HDevWindowStack.GetActive());
                        }
                        if (HDevWindowStack.IsOpen())
                        {
                            HOperatorSet.DispText(HDevWindowStack.GetActive(), "圆环测量结果/mm", "window",
                                0, 0, "black", new HTuple(), new HTuple());
                        }
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            disp_message(hv_WindowHandle, (((new HTuple(4)).TupleConcat(3)).TupleConcat(
                                2)).TupleConcat(1), "image", (hv_RowN.TupleSelectRange(0, 3)) - 20, (hv_ColumnN.TupleSelectRange(
                                0, 3)) - 20, "green", "false");
                        }
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            disp_message(hv_WindowHandle, ((((((new HTuple(11)).TupleConcat(10)).TupleConcat(
                                9)).TupleConcat(8)).TupleConcat(7)).TupleConcat(6)).TupleConcat(5), "image",
                                (hv_RowN.TupleSelectRange(4, 10)) - 20, (hv_ColumnN.TupleSelectRange(4, 10)) - 20,
                                "green", "false");
                        }
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            disp_message(hv_WindowHandle, (((((((new HTuple(19)).TupleConcat(18)).TupleConcat(
                                17)).TupleConcat(16)).TupleConcat(15)).TupleConcat(14)).TupleConcat(13)).TupleConcat(
                                12), "image", (hv_RowN.TupleSelectRange(11, 18)) - 20, (hv_ColumnN.TupleSelectRange(
                                11, 18)) - 20, "green", "false");
                        }
                        HOperatorSet.SetWindowAttr("background_color", "black");
                        HOperatorSet.OpenWindow(0, hv_Width / 3, 400, hv_Height / 3, 0, "visible", "", out hv_WindowHandle2);
                        HDevWindowStack.Push(hv_WindowHandle2);

                        if (HDevWindowStack.IsOpen())
                        {
                            HOperatorSet.DispText(HDevWindowStack.GetActive(), "序号", "window", 0, 0,
                                "black", new HTuple(), new HTuple());
                        }
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            disp_message(hv_WindowHandle2, HTuple.TupleGenSequence(1, 19, 1), "window", 20,
                                5, "black", "true");
                        }

                        if (HDevWindowStack.IsOpen())
                        {
                            HOperatorSet.DispText(HDevWindowStack.GetActive(), "外圆半径", "window",
                                0, 40, "black", new HTuple(), new HTuple());
                        }
                        disp_message(hv_WindowHandle2, hv_TrueWR, "window", 20, 40, "black", "true");

                        if (HDevWindowStack.IsOpen())
                        {
                            HOperatorSet.DispText(HDevWindowStack.GetActive(), "内圆半径", "window",
                                0, 100, "black", new HTuple(), new HTuple());
                        }
                        disp_message(hv_WindowHandle2, hv_TrueNR, "window", 20, 100, "black", "true");

                        if (HDevWindowStack.IsOpen())
                        {
                            HOperatorSet.DispText(HDevWindowStack.GetActive(), "圆环平均厚度", "window",
                                0, 160, "black", new HTuple(), new HTuple());
                        }
                        disp_message(hv_WindowHandle2, hv_AverageR, "window", 20, 170, "black", "true");

                        if (HDevWindowStack.IsOpen())
                        {
                            HOperatorSet.DispText(HDevWindowStack.GetActive(), "圆环最大最小值", "window",
                                330, 10, "black", new HTuple(), new HTuple());
                        }
                        using (HDevDisposeHelper dh = new HDevDisposeHelper())
                        {
                            disp_message(hv_WindowHandle2, (new HTuple("Max=")).TupleConcat("Min=") + (hv_Max1.TupleConcat(
                                hv_Min1)), "window", 330, 110, "black", "true");
                        }

                        if (HDevWindowStack.IsOpen())
                        {
                            HOperatorSet.DispText(HDevWindowStack.GetActive(), "圆环X坐标", "window",
                                0, 240, "black", new HTuple(), new HTuple());
                        }
                        disp_message(hv_WindowHandle2, hv_x, "window", 20, 250, "black", "true");
                        //disp_message(hv_WindowHandle2, hv_y, "window", 20, 310, "black", "true");
                        //disp_continue_message (WindowHandle, 'black', 'true')
                        //stop ()

                        if (HDevWindowStack.IsOpen())
                        {
                            HOperatorSet.DispText(HDevWindowStack.GetActive(), "圆环Y坐标", "window",
                                0, 300, "black", new HTuple(), new HTuple());
                        }
                        disp_message(hv_WindowHandle2, hv_y, "window", 20, 310, "black", "true");
                        
                        if (HDevWindowStack.IsOpen())
                        {
                            //dev_clear_window ()
                        }
                        set_display_font(hv_WindowHandle, 20, "mono", "true", "false");
                        disp_message(hv_WindowHandle, "测量完成!", "window", 0, 0, "black", "true");
                        // stop(...); only in hdevelop
                    }
                    else
                    {
                        MessageBox.Show("未输入检测文件或标定图");
                    }
                }
                catch (HalconException HDevExpDefaultException)
                {
                    ho_Image2.Dispose();
                    ho_Image.Dispose();
                    ho_Regions.Dispose();
                    ho_ConnectedRegions.Dispose();
                    ho_RegionFillUp.Dispose();
                    ho_SelectedRegions.Dispose();
                    ho_RegionDifference.Dispose();

                    hv_Width.Dispose();
                    hv_Height.Dispose();
                    hv_O.Dispose();
                    hv_RM1.Dispose();
                    hv_TM.Dispose();
                    hv_Ratio.Dispose();
                    hv_WindowHandle.Dispose();
                    hv_Number.Dispose();
                    hv_AreaW.Dispose();
                    hv_RowW.Dispose();
                    hv_ColumnW.Dispose();
                    hv_WR.Dispose();
                    hv_MatrixIDW.Dispose();
                    hv_TrueWR.Dispose();
                    hv_MatrixMultIDW.Dispose();
                    hv_ValuesW.Dispose();
                    hv_X.Dispose();
                    hv_Y.Dispose();
                    hv_AreaN.Dispose();
                    hv_RowN.Dispose();
                    hv_ColumnN.Dispose();
                    hv_NR.Dispose();
                    hv_MatrixIDN.Dispose();
                    hv_TrueNR.Dispose();
                    hv_MatrixMultIDN.Dispose();
                    hv_ValuesN.Dispose();
                    hv_x.Dispose();
                    hv_y.Dispose();
                    hv_Row.Dispose();
                    hv_Column.Dispose();
                    hv_Radius.Dispose();
                    hv_Row1.Dispose();
                    hv_Column1.Dispose();
                    hv_Radius1.Dispose();
                    hv_Max.Dispose();
                    hv_Max1.Dispose();
                    hv_Row2.Dispose();
                    hv_Column2.Dispose();
                    hv_Radius2.Dispose();
                    hv_Row3.Dispose();
                    hv_Column3.Dispose();
                    hv_Radius3.Dispose();
                    hv_Min.Dispose();
                    hv_Min1.Dispose();
                    hv_AverageR.Dispose();
                    hv_WindowHandle2.Dispose();

                    throw HDevExpDefaultException;
                }

                ho_Image2.Dispose();
                ho_Image.Dispose();
                ho_Regions.Dispose();
                ho_ConnectedRegions.Dispose();
                ho_RegionFillUp.Dispose();
                ho_SelectedRegions.Dispose();
                ho_RegionDifference.Dispose();

                hv_Width.Dispose();
                hv_Height.Dispose();
                hv_O.Dispose();
                hv_RM1.Dispose();
                hv_TM.Dispose();
                hv_Ratio.Dispose();
                hv_WindowHandle.Dispose();
                hv_Number.Dispose();
                hv_AreaW.Dispose();
                hv_RowW.Dispose();
                hv_ColumnW.Dispose();
                hv_WR.Dispose();
                hv_MatrixIDW.Dispose();
                hv_TrueWR.Dispose();
                hv_MatrixMultIDW.Dispose();
                hv_ValuesW.Dispose();
                hv_X.Dispose();
                hv_Y.Dispose();
                hv_AreaN.Dispose();
                hv_RowN.Dispose();
                hv_ColumnN.Dispose();
                hv_NR.Dispose();
                hv_MatrixIDN.Dispose();
                hv_TrueNR.Dispose();
                hv_MatrixMultIDN.Dispose();
                hv_ValuesN.Dispose();
                hv_x.Dispose();
                hv_y.Dispose();
                hv_Row.Dispose();
                hv_Column.Dispose();
                hv_Radius.Dispose();
                hv_Row1.Dispose();
                hv_Column1.Dispose();
                hv_Radius1.Dispose();
                hv_Max.Dispose();
                hv_Max1.Dispose();
                hv_Row2.Dispose();
                hv_Column2.Dispose();
                hv_Radius2.Dispose();
                hv_Row3.Dispose();
                hv_Column3.Dispose();
                hv_Radius3.Dispose();
                hv_Min.Dispose();
                hv_Min1.Dispose();
                hv_AverageR.Dispose();
                hv_WindowHandle2.Dispose();

            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }


        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HalconDotNet;
using System.Threading;

namespace ImageShow
{
    public partial class Form1 : Form
    {
        //定义全局变量
        HTuple hv_Windowld;
        HTuple hv_AcqHandle;
        HObject ho_Image;
        HTuple hv_Width, hv_Height;
        bool is_GetImage = false;
        string path = @"G:\SoftwareLearning\halcon\ImageProcess\image\";
        string _str = "";
        public Form1()
        {
            InitializeComponent();
        }

        Thread thGetImage;
        private void GetImage_Click(object sender, EventArgs e)
        {
            if (is_GetImage == false)
            {
                is_GetImage = true;
                thGetImage = new Thread(ThreadGetImage);
                thGetImage.Start();
                thGetImage.IsBackground = true;
                GetImage.Text = "停止";
                
            }
            else
            {
                is_GetImage = false;
                thGetImage.Abort();
                GetImage.Text = "实时";
            }
            //保存图像
            HOperatorSet.WriteImage(ho_Image, "png",0, path + ".png");
            _str = "图片保存完成";
            MessageBox.Show(_str);
        }
        //定义实时采图的线程
        private void ThreadGetImage()
        {
            while (true)
            {
                //先销毁对象,避免内存泄漏
                ho_Image.Dispose();
                //采图显示
                HOperatorSet.GrabImage(out ho_Image, hv_AcqHandle);
                HOperatorSet.DispObj(ho_Image, hv_Windowld);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //打开窗口
            HOperatorSet.OpenWindow(0, 0, pictureBoxShow.Width, pictureBoxShow.Height, pictureBoxShow.Handle, "", "", out hv_Windowld);
            //连接相机
            HOperatorSet.OpenFramegrabber("DirectShow", 1, 1, 0, 0, 0, 0, "default", 8, "rgb", -1, "false", "default", "[0] ", 0, -1, out hv_AcqHandle);
            //采集图像
            HOperatorSet.GrabImage(out  ho_Image, hv_AcqHandle);
            //获取图像大小
            HOperatorSet.GetImageSize(ho_Image,out hv_Width, out hv_Height);
            //设置在窗口中显示图像(不是实时显示)
            HOperatorSet.SetPart(hv_Windowld,0,0, hv_Height, hv_Width);
            HOperatorSet.DispObj(ho_Image, hv_Windowld);
        }
    }
}

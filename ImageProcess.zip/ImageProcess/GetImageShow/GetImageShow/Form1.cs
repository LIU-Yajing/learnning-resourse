﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HalconDotNet;

namespace GetImageShow
{
    public partial class Form1 : Form
    {
        HTuple hv_Windowld;
        HTuple hv_AcqHandle;
        HObject ho_Image, ho_GrayImage;
        HTuple hv_count = 10;
        HTuple hv_Mean, hv_Deviation, hv_Ret, hv_Index;
        HTuple hv_index1;
        HTuple hv_Width, hv_Height;
        bool is_GetImage = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //打开窗口
            HOperatorSet.OpenWindow(0, 0, pictureBoxShow.Width, pictureBoxShow.Height, pictureBoxShow.Handle, "", "", out hv_Windowld);
            //连接相机
            HOperatorSet.OpenFramegrabber("DirectShow", 1, 1, 0, 0, 0, 0, "default", 8, "rgb", -1, "false", "default", "[0] ", 0, -1, out hv_AcqHandle);

     
            for (hv_Index = 1; hv_Index <  hv_count; hv_Index ++)
            {
                //采集图像
                HOperatorSet.GrabImage(out ho_Image, hv_AcqHandle);
                //灰度化
                HOperatorSet.Rgb1ToGray(ho_Image, out ho_GrayImage);
                //计算方差
                HOperatorSet.Intensity(ho_GrayImage, ho_GrayImage, out hv_Mean, out hv_Deviation);
                //暂停0.5s
                HOperatorSet.WaitSeconds(0.5);
                //获取图像大小
                HOperatorSet.GetImageSize(ho_Image, out hv_Width, out hv_Height);
                //设置在窗口中显示图像(不是实时显示)
                HOperatorSet.SetPart(hv_Windowld, 0, 0, hv_Height, hv_Width);
                HOperatorSet.DispObj(ho_Image, hv_Windowld);

                
                 /*
                //保存清晰度数据
                HTuple ExpTmpLocalVar_Ret = hv_Ret.TupleConcat(hv_Deviation);
                hv_Ret.Dispose();
                hv_Ret = ExpTmpLocalVar_Ret;
                //寻找最大值
                hv_index1 = hv_Ret.TupleFind(hv_Ret.TupleMax());
                */
            }
            
            HOperatorSet.CloseFramegrabber(hv_AcqHandle);
        }
    }
}
